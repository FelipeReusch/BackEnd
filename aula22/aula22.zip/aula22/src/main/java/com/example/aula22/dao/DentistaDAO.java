package com.example.aula22.dao;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DentistaDAO {
    private Integer id;
    private String nome;
    private String sobrenome;
    private String matricula;
}
